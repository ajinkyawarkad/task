export const firebaseConfig = {
    fire :{
        
        apiKey: "AIzaSyALh0_RQqpQWHXFe6hS-ojWftaY3-aopTQ",
        authDomain: "adminsale-93b98.firebaseapp.com",
        projectId: "adminsale-93b98",
        storageBucket: "adminsale-93b98.appspot.com",
        messagingSenderId: "242169418061",
        appId: "1:242169418061:web:46b8ddbce7ace3bbfe6704",
        measurementId: "G-M8M7QBJB54"
    }

}